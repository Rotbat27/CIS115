﻿namespace MoveEstimator
{
    partial class MoveEstimator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MoveEstimatorLabel = new System.Windows.Forms.Label();
            this.numberHoursLabel = new System.Windows.Forms.Label();
            this.numberMilesLabel = new System.Windows.Forms.Label();
            this.calculateCostButton = new System.Windows.Forms.Button();
            this.totalEstimateLabel = new System.Windows.Forms.Label();
            this.estimateLabel = new System.Windows.Forms.Label();
            this.enterHoursButton = new System.Windows.Forms.TextBox();
            this.enterMilesButton = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // MoveEstimatorLabel
            // 
            this.MoveEstimatorLabel.AutoSize = true;
            this.MoveEstimatorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoveEstimatorLabel.Location = new System.Drawing.Point(287, 9);
            this.MoveEstimatorLabel.Name = "MoveEstimatorLabel";
            this.MoveEstimatorLabel.Size = new System.Drawing.Size(218, 33);
            this.MoveEstimatorLabel.TabIndex = 0;
            this.MoveEstimatorLabel.Text = "Move Estimator";
            // 
            // numberHoursLabel
            // 
            this.numberHoursLabel.AutoSize = true;
            this.numberHoursLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberHoursLabel.Location = new System.Drawing.Point(204, 87);
            this.numberHoursLabel.Name = "numberHoursLabel";
            this.numberHoursLabel.Size = new System.Drawing.Size(199, 20);
            this.numberHoursLabel.TabIndex = 1;
            this.numberHoursLabel.Text = "Enter the number of hours:";
            // 
            // numberMilesLabel
            // 
            this.numberMilesLabel.AutoSize = true;
            this.numberMilesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberMilesLabel.Location = new System.Drawing.Point(204, 145);
            this.numberMilesLabel.Name = "numberMilesLabel";
            this.numberMilesLabel.Size = new System.Drawing.Size(195, 20);
            this.numberMilesLabel.TabIndex = 2;
            this.numberMilesLabel.Text = "Enter the number of miles:";
            // 
            // calculateCostButton
            // 
            this.calculateCostButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateCostButton.Location = new System.Drawing.Point(208, 233);
            this.calculateCostButton.Name = "calculateCostButton";
            this.calculateCostButton.Size = new System.Drawing.Size(206, 37);
            this.calculateCostButton.TabIndex = 3;
            this.calculateCostButton.Text = "Click to Caculate";
            this.calculateCostButton.UseVisualStyleBackColor = true;
            this.calculateCostButton.Click += new System.EventHandler(this.calculateCostButton_Click);
            // 
            // totalEstimateLabel
            // 
            this.totalEstimateLabel.AutoSize = true;
            this.totalEstimateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalEstimateLabel.Location = new System.Drawing.Point(369, 253);
            this.totalEstimateLabel.Name = "totalEstimateLabel";
            this.totalEstimateLabel.Size = new System.Drawing.Size(0, 20);
            this.totalEstimateLabel.TabIndex = 4;
            // 
            // estimateLabel
            // 
            this.estimateLabel.AutoSize = true;
            this.estimateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estimateLabel.Location = new System.Drawing.Point(438, 243);
            this.estimateLabel.Name = "estimateLabel";
            this.estimateLabel.Size = new System.Drawing.Size(72, 20);
            this.estimateLabel.TabIndex = 5;
            this.estimateLabel.Text = "Estimate";
            this.estimateLabel.Visible = false;
            // 
            // enterHoursButton
            // 
            this.enterHoursButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterHoursButton.Location = new System.Drawing.Point(410, 81);
            this.enterHoursButton.Name = "enterHoursButton";
            this.enterHoursButton.Size = new System.Drawing.Size(100, 26);
            this.enterHoursButton.TabIndex = 6;
            // 
            // enterMilesButton
            // 
            this.enterMilesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterMilesButton.Location = new System.Drawing.Point(410, 139);
            this.enterMilesButton.Name = "enterMilesButton";
            this.enterMilesButton.Size = new System.Drawing.Size(100, 26);
            this.enterMilesButton.TabIndex = 7;
            // 
            // MoveEstimator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.enterMilesButton);
            this.Controls.Add(this.enterHoursButton);
            this.Controls.Add(this.estimateLabel);
            this.Controls.Add(this.totalEstimateLabel);
            this.Controls.Add(this.calculateCostButton);
            this.Controls.Add(this.numberMilesLabel);
            this.Controls.Add(this.numberHoursLabel);
            this.Controls.Add(this.MoveEstimatorLabel);
            this.Name = "MoveEstimator";
            this.Text = "Move Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MoveEstimatorLabel;
        private System.Windows.Forms.Label numberHoursLabel;
        private System.Windows.Forms.Label numberMilesLabel;
        private System.Windows.Forms.Button calculateCostButton;
        private System.Windows.Forms.Label totalEstimateLabel;
        private System.Windows.Forms.Label estimateLabel;
        private System.Windows.Forms.TextBox enterHoursButton;
        private System.Windows.Forms.TextBox enterMilesButton;
    }
}

