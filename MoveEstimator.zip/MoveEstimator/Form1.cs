﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoveEstimator
{
    public partial class MoveEstimator : Form
    {
        public MoveEstimator()
        {
            InitializeComponent();
        }

        private void calculateCostButton_Click(object sender, EventArgs e)
        {
            estimateLabel.Visible = true;
            const double baseRate = 200.00;
            const double hourRate = 150.00;
            const double mileRate = 2.00;
            double hoursEntered;
            double milesEntered;
            double sumOfEstimate;
            hoursEntered = Convert.ToInt32(enterHoursButton.Text);
            milesEntered = Convert.ToInt32(enterMilesButton.Text);
            sumOfEstimate = baseRate + ((hoursEntered * hourRate) + (milesEntered * mileRate));
            estimateLabel.Text = String.Format("For a move taking {0} hours and going {1} miles the estimate is ${2}", hoursEntered, milesEntered, sumOfEstimate);
        }
    }
}
