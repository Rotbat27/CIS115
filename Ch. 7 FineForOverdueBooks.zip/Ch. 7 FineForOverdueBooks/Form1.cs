﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch_7.FineForOverdueBooks
{
    public partial class FineCalcForm : Form
    {
        public FineCalcForm()
        {
            InitializeComponent();
        }

        private void calcBut_Click(object sender, EventArgs e)
        {
            double numOfBooks;
            double daysOverdue;
            if (double.TryParse(numBooksTextbox.Text, out numOfBooks) && double.TryParse(daysOverDueTextbox.Text, out daysOverdue))
            {
                calcFine(numOfBooks, daysOverdue);
            }

            else
            {
                MessageBox.Show("ERROR. Please enter a number in each box.");
            }
        }

        private void calcFine(double books, double days)
        {
            double fineAmount;
            if (days < 0)
            {
                MessageBox.Show("ERROR. Please enter a valid number of days.");
                daysOverDueTextbox.Text = ("");
            }

            else if (days > 0 && days <= 7)
            {
                fineAmount = (books * days) * 0.10;
                outputLabel.Text = String.Format("You owe ${0} in overdue fines.", fineAmount.ToString("0.00"));
            }

            else
            {
                fineAmount = (((days - 7) * books) * 0.20) + ((books * 7) * 0.10);
                outputLabel.Text = String.Format("You owe ${0} in overdue fines.", fineAmount.ToString("0.00"));
            }
        }
    }
}
