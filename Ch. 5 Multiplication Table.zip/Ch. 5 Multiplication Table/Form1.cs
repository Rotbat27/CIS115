﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch._5_Multiplication_Table
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void multButton_Click(object sender, EventArgs e)
        {
            int enterNum;
            enterNum = Convert.ToInt32(intTextbox.Text);
            int multNum;
            int outNum;
            const int highCutoff = 10;
            const int lowCutoff = 0;
            const int multStep = 1;
            multNum = lowCutoff;
            if (enterNum <0 || enterNum >999999)
                outputLabel1.Text=("Invalid input. Please input number between 0 and 999999");
            else 
            {
                outputLabel1.Text = ("");
                for (multNum = lowCutoff; multNum <= highCutoff; multNum++)
                {
                    outNum = enterNum * multNum;
                    outputLabel1.Text += String.Format("{0} multiplied by {1} is equal to {2}\n", enterNum, multNum, outNum);
                }
            }
        }
    }
}
