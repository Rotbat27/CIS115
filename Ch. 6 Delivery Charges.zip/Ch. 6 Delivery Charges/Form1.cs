﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch._6_Delivery_Charges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] _zipCodes = {    28901,  28903, 28905, 28906, 30582, 27564, 29056, 32512, 19824,  19745};
        double[] _shipPrices = {8.10,  9.10,  9.15,  1.00,  13.74, 18.57, 22.35, 7.12,  108.44, 11.56 };
        private void determBut_Click(object sender, EventArgs e)
        {
            int enterZip;
            double shipPrice = 0;
            bool isValidZip = false;
            if (int.TryParse(enterZipTextbox.Text, out enterZip))
            {

//-------------arbitrary variable, chose z for zipcode
                for (int z = 0; z < _zipCodes.Length; ++z)
                {

                    if (enterZip == _zipCodes[z])
                    {
                        isValidZip = true;
                        shipPrice = _shipPrices[z];
                    }
                }

                if (isValidZip)
                {
 //------------------------------------------------------------------------------------------------------added ToString to force 2 decimal places 
                    outputLabel.Text = String.Format("The price to ship to zip code {0}\nis equal to ${1}", enterZip, shipPrice.ToString("0.00"));
                }

                else
                {
                    outputLabel.Text = ("Sorry, it appears we cannot ship\nto the zip code you have entered.");
                }
            }

            else
            {
                MessageBox.Show("ERROR. Please enter a zip code in\nnumeric digits only. Thank you.");
                enterZipTextbox.Text = ("");
            }
        }
    }
}
