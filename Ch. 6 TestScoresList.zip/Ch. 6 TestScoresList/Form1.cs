﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch._6_TestScoresList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] scoreList = { 0, 0, 0, 0, 0, 0, 0, 0 };
        private void enterBut_Click(object sender, EventArgs e)
        {
            int enteredScore;
            int enterWhich;
            int cutOff = 0;
            const int lowEnterMax = 1;
            const int highEnterMax = 8;

            if (int.TryParse(enterScoreTextbox.Text, out enteredScore) && int.TryParse(enterWhichTextbox.Text, out enterWhich))
            {

                if ((int.Parse(enterWhichTextbox.Text) < lowEnterMax || (int.Parse(enterWhichTextbox.Text) > highEnterMax)))
                {
                    MessageBox.Show("ERROR. Please enter only numbers 1-8\ncorresponding to which test the score is for.");
                    enterScoreTextbox.Text = ("");
                    enterWhichTextbox.Text = ("");
                }

                else
                {
                    --enterWhich;
                    scoreList[enterWhich] += enteredScore;
                    enterScoreTextbox.Text = ("");
                    enterWhichTextbox.Text = ("");
                    outputLabel.Text = ("Enter another test and score");
                    ++cutOff;

                    if (cutOff == 8)
                    {
                        enterBut.Enabled = false;
                        enterWhichTextbox.Enabled = false;
                        enterScoreTextbox.Enabled = false;
                    }
                }
            }

            else
            {
                MessageBox.Show("ERROR. Please enter only numeric digits.");
                enterScoreTextbox.Text = ("");
                enterWhichTextbox.Text = ("");
            }
        }

        private void finishedBut_Click(object sender, EventArgs e)
        {
            enterBut.Enabled = false;
            outputLabel.Text = ("");
            int total = 0;
            int avg;
            foreach (int scores in scoreList)
            {
                total += scores;
            }
            for (int x = 0; x < scoreList.Length; ++x)
            {
                avg = total / scoreList.Length;
                int distanceFrom = scoreList[x] - avg;
                    outputLabel.Text +=
                        String.Format("The {0} score  {1}  is  {2}  away from the average {3}\n", x + 1, scoreList[x].ToString("G"), distanceFrom, avg);
            }
        }
    }
}
