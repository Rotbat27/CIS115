﻿namespace Ch._6_TestScoresList
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.formTitleLabel = new System.Windows.Forms.Label();
            this.expLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.enterScoreTextbox = new System.Windows.Forms.TextBox();
            this.enterBut = new System.Windows.Forms.Button();
            this.finishedBut = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.enterWhichLabel = new System.Windows.Forms.Label();
            this.enterWhichTextbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // formTitleLabel
            // 
            this.formTitleLabel.AutoSize = true;
            this.formTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.formTitleLabel.Location = new System.Drawing.Point(205, 9);
            this.formTitleLabel.Name = "formTitleLabel";
            this.formTitleLabel.Size = new System.Drawing.Size(367, 55);
            this.formTitleLabel.TabIndex = 0;
            this.formTitleLabel.Text = "Test Scores List";
            // 
            // expLabel
            // 
            this.expLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expLabel.Location = new System.Drawing.Point(110, 73);
            this.expLabel.Name = "expLabel";
            this.expLabel.Size = new System.Drawing.Size(544, 45);
            this.expLabel.TabIndex = 1;
            this.expLabel.Text = "Enter 8 test scores into the program, click Finished button, and the program will" +
    " list the test scores with the distance they are from the average.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(224, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Scores Here -->";
            // 
            // enterScoreTextbox
            // 
            this.enterScoreTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterScoreTextbox.Location = new System.Drawing.Point(424, 176);
            this.enterScoreTextbox.Name = "enterScoreTextbox";
            this.enterScoreTextbox.Size = new System.Drawing.Size(100, 29);
            this.enterScoreTextbox.TabIndex = 3;
            // 
            // enterBut
            // 
            this.enterBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterBut.Location = new System.Drawing.Point(312, 230);
            this.enterBut.Name = "enterBut";
            this.enterBut.Size = new System.Drawing.Size(150, 47);
            this.enterBut.TabIndex = 4;
            this.enterBut.Text = "ENTER";
            this.enterBut.UseVisualStyleBackColor = true;
            this.enterBut.Click += new System.EventHandler(this.enterBut_Click);
            // 
            // finishedBut
            // 
            this.finishedBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finishedBut.Location = new System.Drawing.Point(312, 532);
            this.finishedBut.Name = "finishedBut";
            this.finishedBut.Size = new System.Drawing.Size(150, 47);
            this.finishedBut.TabIndex = 5;
            this.finishedBut.Text = "FINISHED";
            this.finishedBut.UseVisualStyleBackColor = true;
            this.finishedBut.Click += new System.EventHandler(this.finishedBut_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.Location = new System.Drawing.Point(114, 292);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(540, 224);
            this.outputLabel.TabIndex = 6;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // enterWhichLabel
            // 
            this.enterWhichLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterWhichLabel.Location = new System.Drawing.Point(151, 147);
            this.enterWhichLabel.Name = "enterWhichLabel";
            this.enterWhichLabel.Size = new System.Drawing.Size(267, 23);
            this.enterWhichLabel.TabIndex = 7;
            this.enterWhichLabel.Text = "Enter which test, 1-10, here -->";
            // 
            // enterWhichTextbox
            // 
            this.enterWhichTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterWhichTextbox.Location = new System.Drawing.Point(424, 141);
            this.enterWhichTextbox.Name = "enterWhichTextbox";
            this.enterWhichTextbox.Size = new System.Drawing.Size(100, 29);
            this.enterWhichTextbox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 591);
            this.Controls.Add(this.enterWhichTextbox);
            this.Controls.Add(this.enterWhichLabel);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.finishedBut);
            this.Controls.Add(this.enterBut);
            this.Controls.Add(this.enterScoreTextbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.expLabel);
            this.Controls.Add(this.formTitleLabel);
            this.Name = "Form1";
            this.Text = "TestScoresList";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label formTitleLabel;
        private System.Windows.Forms.Label expLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox enterScoreTextbox;
        private System.Windows.Forms.Button enterBut;
        private System.Windows.Forms.Button finishedBut;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label enterWhichLabel;
        private System.Windows.Forms.TextBox enterWhichTextbox;
    }
}

