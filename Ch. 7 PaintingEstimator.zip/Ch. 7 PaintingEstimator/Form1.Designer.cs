﻿namespace Ch._7_PaintingEstimator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.expLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.enterLengthTextbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.enterWidthTextbox = new System.Windows.Forms.TextBox();
            this.calcBut = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(192, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(396, 55);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Painting Estimate";
            // 
            // expLabel
            // 
            this.expLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expLabel.Location = new System.Drawing.Point(202, 64);
            this.expLabel.Name = "expLabel";
            this.expLabel.Size = new System.Drawing.Size(386, 45);
            this.expLabel.TabIndex = 1;
            this.expLabel.Text = "We are assuming that we are only painting the walls, not floor and ceiling, and t" +
    "hat the walls are 9 feet tall.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(243, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter length here -->";
            // 
            // enterLengthTextbox
            // 
            this.enterLengthTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterLengthTextbox.Location = new System.Drawing.Point(433, 137);
            this.enterLengthTextbox.Name = "enterLengthTextbox";
            this.enterLengthTextbox.Size = new System.Drawing.Size(100, 29);
            this.enterLengthTextbox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(243, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter width here -->";
            // 
            // enterWidthTextbox
            // 
            this.enterWidthTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterWidthTextbox.Location = new System.Drawing.Point(433, 182);
            this.enterWidthTextbox.Name = "enterWidthTextbox";
            this.enterWidthTextbox.Size = new System.Drawing.Size(100, 29);
            this.enterWidthTextbox.TabIndex = 5;
            // 
            // calcBut
            // 
            this.calcBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcBut.Location = new System.Drawing.Point(297, 231);
            this.calcBut.Name = "calcBut";
            this.calcBut.Size = new System.Drawing.Size(177, 51);
            this.calcBut.TabIndex = 6;
            this.calcBut.Text = "CALCULATE";
            this.calcBut.UseVisualStyleBackColor = true;
            this.calcBut.Click += new System.EventHandler(this.calcBut_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.Location = new System.Drawing.Point(202, 309);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(386, 114);
            this.outputLabel.TabIndex = 7;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.calcBut);
            this.Controls.Add(this.enterWidthTextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.enterLengthTextbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.expLabel);
            this.Controls.Add(this.titleLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label expLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox enterLengthTextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox enterWidthTextbox;
        private System.Windows.Forms.Button calcBut;
        private System.Windows.Forms.Label outputLabel;
    }
}

