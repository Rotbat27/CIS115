﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch._7_PaintingEstimator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcBut_Click(object sender, EventArgs e)
        {
            double roomLength;
            double roomWidth;
            if (double.TryParse(enterLengthTextbox.Text, out roomLength) && double.TryParse(enterWidthTextbox.Text, out roomWidth))
            {
                double totalCost;
                totalCost = RoomCostEstimate(roomLength, roomWidth);
                outputLabel.Text = String.Format("For the length and width you entered,\nthe price for painting the room is ${0}\nat $6.00 per square footage.", totalCost.ToString("0.00"));
            }

            else
            {
                MessageBox.Show("ERROR. Please enter numeric length and width.");
                enterLengthTextbox.Text = ("");
                enterWidthTextbox.Text = ("");
            }
        }

        private static double RoomCostEstimate(double length, double width)
        {
            const double chargeRate = 6.00;
            double wallOne;
            double wallTwo;
            double cost;
            wallOne = (((length * 9) * chargeRate) * 2);
            wallTwo = (((width * 9) * chargeRate) * 2);
            cost = wallOne + wallTwo;
            return cost;
        }
    }
}
