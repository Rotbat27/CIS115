﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TweetLengthEval
{
    public partial class Twitter : Form
    {
        public Twitter()
        {
            InitializeComponent();
        }

        private void determineButton_Click(object sender, EventArgs e)
        {
            answerLabel.Visible = true;
            const int TooHigh = 141, TooLow = 0;
            string enteredText;
            enteredText = Convert.ToString(enterTweetTextbox.Text);
            if (enteredText.Length == 0)
                answerLabel.Text = String.Format("Please enter some text into the above textbox.");
            if (enteredText.Length > TooLow)
                if (enteredText.Length < TooHigh)
                    answerLabel.Text = String.Format("This tweet is short enough to be posted!");
                else
                    answerLabel.Text = String.Format("Error: this tweet is outside the character limits!");

        }
    }
}
