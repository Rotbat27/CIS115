﻿namespace TweetLengthEval
{
    partial class Twitter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tweetEvaluatorLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.enterTweetLabel = new System.Windows.Forms.Label();
            this.enterTweetTextbox = new System.Windows.Forms.TextBox();
            this.determineButton = new System.Windows.Forms.Button();
            this.answerLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tweetEvaluatorLabel
            // 
            this.tweetEvaluatorLabel.AutoSize = true;
            this.tweetEvaluatorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tweetEvaluatorLabel.Location = new System.Drawing.Point(269, 9);
            this.tweetEvaluatorLabel.Name = "tweetEvaluatorLabel";
            this.tweetEvaluatorLabel.Size = new System.Drawing.Size(282, 39);
            this.tweetEvaluatorLabel.TabIndex = 0;
            this.tweetEvaluatorLabel.Text = "Tweet Evaluator";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLabel.Location = new System.Drawing.Point(88, 48);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(630, 29);
            this.descriptionLabel.TabIndex = 1;
            this.descriptionLabel.Text = "Enter your tweet and see if it is short enough to be posted!";
            // 
            // enterTweetLabel
            // 
            this.enterTweetLabel.AutoSize = true;
            this.enterTweetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterTweetLabel.Location = new System.Drawing.Point(135, 139);
            this.enterTweetLabel.Name = "enterTweetLabel";
            this.enterTweetLabel.Size = new System.Drawing.Size(184, 24);
            this.enterTweetLabel.TabIndex = 2;
            this.enterTweetLabel.Text = "Enter the tweet here:";
            // 
            // enterTweetTextbox
            // 
            this.enterTweetTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterTweetTextbox.Location = new System.Drawing.Point(325, 134);
            this.enterTweetTextbox.Multiline = true;
            this.enterTweetTextbox.Name = "enterTweetTextbox";
            this.enterTweetTextbox.Size = new System.Drawing.Size(393, 29);
            this.enterTweetTextbox.TabIndex = 3;
            // 
            // determineButton
            // 
            this.determineButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.determineButton.Location = new System.Drawing.Point(262, 262);
            this.determineButton.Name = "determineButton";
            this.determineButton.Size = new System.Drawing.Size(289, 49);
            this.determineButton.TabIndex = 4;
            this.determineButton.Text = "Click to Determine!";
            this.determineButton.UseVisualStyleBackColor = true;
            this.determineButton.Click += new System.EventHandler(this.determineButton_Click);
            // 
            // answerLabel
            // 
            this.answerLabel.AutoSize = true;
            this.answerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerLabel.Location = new System.Drawing.Point(198, 389);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(0, 25);
            this.answerLabel.TabIndex = 5;
            this.answerLabel.Visible = false;
            // 
            // Twitter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 616);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.determineButton);
            this.Controls.Add(this.enterTweetTextbox);
            this.Controls.Add(this.enterTweetLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.tweetEvaluatorLabel);
            this.Name = "Twitter";
            this.Text = "Twitter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tweetEvaluatorLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label enterTweetLabel;
        private System.Windows.Forms.TextBox enterTweetTextbox;
        private System.Windows.Forms.Button determineButton;
        private System.Windows.Forms.Label answerLabel;
    }
}

