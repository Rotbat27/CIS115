﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Ch._5_Daily_Temps
{
    public partial class Form1 : Form
    {
        private List <double> temps = new List <double> ();
        private int enterNumCutoff = 0;
        private double enteredTemps;
        private double avgTemp = 0;
        private const int CUTOFFMAX = 7;
        private const double LOWTEMP = -20.00;
        private const double HIGHTEMP = 130.00;

        public Form1()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            outputLabel.Visible = true;
            if (double.TryParse(enterTempsTextbox.Text, out enteredTemps))
            {
                if (enteredTemps > LOWTEMP && enteredTemps < HIGHTEMP)
                {
                    temps.Add(enteredTemps);
                    avgTemp += enteredTemps;
                    enterNumCutoff++;

                    if (enterNumCutoff < 7)
                    {
                        outputLabel.Text += String.Format("You entered {0}\n", enteredTemps);
                        enterTempsTextbox.Text = ("");
                    }

                    if (enterNumCutoff == 7)
                    {
                        enterButton.Enabled = false;
                        DisplayResults();
                    }
                }
                else
                {
                    MessageBox.Show("ERROR. Please enter a temperature between -20 and 130");
                }
            }
            else
            {
                MessageBox.Show("ERROR. Please enter a temperature between -20 and 130");
            }
        }
        private void DisplayResults()
        {
            string tempsString = string.Join(", ", temps);
            double answerTemp = avgTemp / 7;
            enterTempsTextbox.Text = ("");
            outputLabel.Text += String.Format("The average is {0}", answerTemp);
        }
    }
}