﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT_Password_Manager_Eric_Fox
{
    public partial class passwordManagerForm : Form
    {
        public passwordManagerForm()
        {
            InitializeComponent();
        }

//      setting up arrays to hold the account type name, usernames, and passwords
        string[] accountNames = new string[1];
        string[] userNamesEmails = new string[1];
        string[] genPassWords = new string[1];

        string masterPassword;
        int accNamePosition;
        int userNamePosition;
        int genPassWordPosition;
        int passwordLength = 0;
        int positionNum = 0;
        string generatedPassword;
        Random character = new Random();


//      This is the method to generate the random password when the generate button is clicked
        private void passwordGenerator(int passwordLength)
        {
            String passCharacters = "ABCDEFGHIJKLMNOPQRSTUVWYZ0123456789abcdefghijklmnopqrstuvwxyz!@#$";
            String createdPassword = "";

            for (int x = 0; x < passwordLength; x++)
            {
                int randomCharNum = character.Next(0, passCharacters.Length);
                createdPassword += passCharacters[randomCharNum];
                outPassLabel.Text = String.Format("{0}", createdPassword);
                generatedPassword = createdPassword;
            }
        }


//      The generate button will use the passwordGenerator method to create a randomized password
        private void generateBtn_Click(object sender, EventArgs e)
        {
            Convert.ToString(masterPassTxtbox.Text);

            if ((acctNameTxtbox.Text.Length > 0 && acctNameTxtbox.Text.Length < 30) && (usrNameTxtbox.Text.Length > 0 && usrNameTxtbox.Text.Length < 30) && (masterPassTxtbox.Text.Length > 0))
            {
                if (masterPassTxtbox.Text == masterPassword)
                {
                    Convert.ToString(acctNameTxtbox.Text);
                    Convert.ToString(usrNameTxtbox.Text);
                    int randPassLength = character.Next(8, 18);
                    int passGenLength;
                    passGenLength = randPassLength;
                    passwordGenerator(randPassLength);

//                  Here I am assigning the input Account and User Names, and the generated password to their respective spot in the arrays
                    accountNames[positionNum] = acctNameTxtbox.Text;
                    userNamesEmails[positionNum] = usrNameTxtbox.Text;
                    genPassWords[positionNum] = generatedPassword;
                    Clipboard.SetText(outPassLabel.Text);
                    masterPassTxtbox.Text = ("");
                    ++positionNum;

//                  This was the only way I could find to extend the size of the array to continue to add more names and passwords
                    Array.Resize(ref accountNames, accountNames.Length + 1);
                    Array.Resize(ref userNamesEmails, userNamesEmails.Length + 1);
                    Array.Resize(ref genPassWords, genPassWords.Length + 1);
                }

                else
                {
                    MessageBox.Show("Master Password Incorrect");
                    acctNameTxtbox.Text = ("");
                    usrNameTxtbox.Text = ("");
                    masterPassTxtbox.Text = ("");
                    outPassLabel.Text = ("");

                }
            }

            else
            {
                MessageBox.Show("Please enter an Account name, Username,\nand the Master Password to generate.");
                acctNameTxtbox.Text = ("");
                usrNameTxtbox.Text = ("");
                masterPassTxtbox.Text = ("");
                outPassLabel.Text = ("");
            }
        }


//      This method was added in just to have an easy way to clear all fields including the output password
        private void clearBtn_Click(object sender, EventArgs e)
        {
            acctNameTxtbox.Text = ("");
            usrNameTxtbox.Text = ("");
            masterPassTxtbox.Text = ("");
            outPassLabel.Text = ("");
        }


//      The set button is to set the master password used to validate attempts to retrieve or generate passwords
        private void setBtn_Click(object sender, EventArgs e)
        {
            if (acctNameTxtbox.Text.Length == 0 && usrNameTxtbox.Text.Length == 0 && masterPassTxtbox.Text.Length > 0)
            {
                Convert.ToString(masterPassTxtbox.Text);
                masterPassword = masterPassTxtbox.Text;
                setBtn.Enabled = false;
                masterPassTxtbox.Text = ("");
            }

            else
            {
                MessageBox.Show("To set a master password,\nMake sure account name and username\nFields are clear of any input.");
                acctNameTxtbox.Text = ("");
                usrNameTxtbox.Text = ("");
                masterPassTxtbox.Text = ("");
            }
        }


//      This method checks the entries of the Account and User names and Master Password and recalls the correct previously generated password
        private void recallBtn_Click(object sender, EventArgs e)
        {
            bool acctNameCheck = false;
            bool usrNameCheck = false;
            string theGenPassword = ("");

            if ((acctNameTxtbox.Text.Length > 0) && (usrNameTxtbox.Text.Length > 0) && (masterPassTxtbox.Text.Length > 0))
            {

                if (masterPassTxtbox.Text == masterPassword)
                {
//                  This for loop searches the arrays for matches against the input text, if found it retrieves the previously generated password and assigns it to a variable
                    for (int p = 0; p < accountNames.Length; ++p)
                    {

                        if ((acctNameTxtbox.Text == accountNames[p]) && (usrNameTxtbox.Text == userNamesEmails[p]))
                        {
                            acctNameCheck = true;
                            usrNameCheck = true;
                            theGenPassword = genPassWords[p];
                        }
                    }

                    if ((acctNameCheck) && (usrNameCheck))
                    {
                        outPassLabel.Text = String.Format("{0}", theGenPassword);

//                      This line copies the output password to your clipboard so you can immediately just paste the password into wherever you are loggin into
                        Clipboard.SetText(outPassLabel.Text);
                    }

                    else
                    {
                        MessageBox.Show("Account/Username could not be found or Master Password was Incorrect.\nPlease double check your entries in all boxes and try again.");
                        acctNameTxtbox.Text = ("");
                        usrNameTxtbox.Text = ("");
                        masterPassTxtbox.Text = ("");
                        outPassLabel.Text = ("");
                    }
                }

                else
                {
                    MessageBox.Show("Account/Username could not be found or Master Password was Incorrect.\nPlease double check your entries in all boxes and try again.");
                    acctNameTxtbox.Text = ("");
                    usrNameTxtbox.Text = ("");
                    masterPassTxtbox.Text = ("");
                    outPassLabel.Text = ("");
                }
            }

            else
            {
                MessageBox.Show("Account/Username could not be found or Master Password was Incorrect.\nPlease double check your entries in all boxes and try again.");
                acctNameTxtbox.Text = ("");
                usrNameTxtbox.Text = ("");
                masterPassTxtbox.Text = ("");
                outPassLabel.Text = ("");
            }
        }
    }
}
