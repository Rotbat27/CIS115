﻿namespace FINAL_PROJECT_Password_Manager_Eric_Fox
{
    partial class passwordManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.accNameLabel = new System.Windows.Forms.Label();
            this.usrNameLabel = new System.Windows.Forms.Label();
            this.entPassLabel = new System.Windows.Forms.Label();
            this.outPassLabel = new System.Windows.Forms.Label();
            this.recallBtn = new System.Windows.Forms.Button();
            this.generateBtn = new System.Windows.Forms.Button();
            this.acctNameTxtbox = new System.Windows.Forms.TextBox();
            this.usrNameTxtbox = new System.Windows.Forms.TextBox();
            this.clearBtn = new System.Windows.Forms.Button();
            this.mastPassLabel = new System.Windows.Forms.Label();
            this.masterPassTxtbox = new System.Windows.Forms.TextBox();
            this.setBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(162, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(469, 50);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Fox Password Manager";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // accNameLabel
            // 
            this.accNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accNameLabel.Location = new System.Drawing.Point(162, 105);
            this.accNameLabel.Name = "accNameLabel";
            this.accNameLabel.Size = new System.Drawing.Size(263, 23);
            this.accNameLabel.TabIndex = 1;
            this.accNameLabel.Text = "Enter Account Name -->";
            // 
            // usrNameLabel
            // 
            this.usrNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usrNameLabel.Location = new System.Drawing.Point(162, 155);
            this.usrNameLabel.Name = "usrNameLabel";
            this.usrNameLabel.Size = new System.Drawing.Size(263, 23);
            this.usrNameLabel.TabIndex = 2;
            this.usrNameLabel.Text = "Enter Username/Email -->";
            // 
            // entPassLabel
            // 
            this.entPassLabel.AutoSize = true;
            this.entPassLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entPassLabel.Location = new System.Drawing.Point(199, 283);
            this.entPassLabel.Name = "entPassLabel";
            this.entPassLabel.Size = new System.Drawing.Size(138, 25);
            this.entPassLabel.TabIndex = 3;
            this.entPassLabel.Text = "Password -->";
            // 
            // outPassLabel
            // 
            this.outPassLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outPassLabel.Location = new System.Drawing.Point(343, 283);
            this.outPassLabel.Name = "outPassLabel";
            this.outPassLabel.Size = new System.Drawing.Size(317, 60);
            this.outPassLabel.TabIndex = 4;
            // 
            // recallBtn
            // 
            this.recallBtn.BackColor = System.Drawing.Color.OldLace;
            this.recallBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recallBtn.Location = new System.Drawing.Point(147, 392);
            this.recallBtn.Name = "recallBtn";
            this.recallBtn.Size = new System.Drawing.Size(204, 56);
            this.recallBtn.TabIndex = 5;
            this.recallBtn.Text = "RECALL";
            this.recallBtn.UseVisualStyleBackColor = false;
            this.recallBtn.Click += new System.EventHandler(this.recallBtn_Click);
            // 
            // generateBtn
            // 
            this.generateBtn.BackColor = System.Drawing.Color.OldLace;
            this.generateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateBtn.Location = new System.Drawing.Point(456, 392);
            this.generateBtn.Name = "generateBtn";
            this.generateBtn.Size = new System.Drawing.Size(204, 56);
            this.generateBtn.TabIndex = 6;
            this.generateBtn.Text = "GENERATE";
            this.generateBtn.UseVisualStyleBackColor = false;
            this.generateBtn.Click += new System.EventHandler(this.generateBtn_Click);
            // 
            // acctNameTxtbox
            // 
            this.acctNameTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctNameTxtbox.Location = new System.Drawing.Point(435, 102);
            this.acctNameTxtbox.Name = "acctNameTxtbox";
            this.acctNameTxtbox.Size = new System.Drawing.Size(229, 31);
            this.acctNameTxtbox.TabIndex = 7;
            // 
            // usrNameTxtbox
            // 
            this.usrNameTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usrNameTxtbox.Location = new System.Drawing.Point(435, 152);
            this.usrNameTxtbox.Name = "usrNameTxtbox";
            this.usrNameTxtbox.Size = new System.Drawing.Size(229, 31);
            this.usrNameTxtbox.TabIndex = 8;
            // 
            // clearBtn
            // 
            this.clearBtn.BackColor = System.Drawing.Color.OldLace;
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(147, 490);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(204, 56);
            this.clearBtn.TabIndex = 9;
            this.clearBtn.Text = "CLEAR FIELDS";
            this.clearBtn.UseVisualStyleBackColor = false;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // mastPassLabel
            // 
            this.mastPassLabel.AutoSize = true;
            this.mastPassLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mastPassLabel.Location = new System.Drawing.Point(162, 209);
            this.mastPassLabel.Name = "mastPassLabel";
            this.mastPassLabel.Size = new System.Drawing.Size(267, 25);
            this.mastPassLabel.TabIndex = 10;
            this.mastPassLabel.Text = "Enter Master Password -->";
            // 
            // masterPassTxtbox
            // 
            this.masterPassTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.masterPassTxtbox.Location = new System.Drawing.Point(435, 206);
            this.masterPassTxtbox.Name = "masterPassTxtbox";
            this.masterPassTxtbox.Size = new System.Drawing.Size(229, 31);
            this.masterPassTxtbox.TabIndex = 11;
            // 
            // setBtn
            // 
            this.setBtn.BackColor = System.Drawing.Color.OldLace;
            this.setBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setBtn.Location = new System.Drawing.Point(456, 490);
            this.setBtn.Name = "setBtn";
            this.setBtn.Size = new System.Drawing.Size(204, 56);
            this.setBtn.TabIndex = 12;
            this.setBtn.Text = "SET";
            this.setBtn.UseVisualStyleBackColor = false;
            this.setBtn.Click += new System.EventHandler(this.setBtn_Click);
            // 
            // passwordManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 558);
            this.Controls.Add(this.setBtn);
            this.Controls.Add(this.masterPassTxtbox);
            this.Controls.Add(this.mastPassLabel);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.usrNameTxtbox);
            this.Controls.Add(this.acctNameTxtbox);
            this.Controls.Add(this.generateBtn);
            this.Controls.Add(this.recallBtn);
            this.Controls.Add(this.outPassLabel);
            this.Controls.Add(this.entPassLabel);
            this.Controls.Add(this.usrNameLabel);
            this.Controls.Add(this.accNameLabel);
            this.Controls.Add(this.titleLabel);
            this.Name = "passwordManagerForm";
            this.Text = "Fox Password Manager";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label accNameLabel;
        private System.Windows.Forms.Label usrNameLabel;
        private System.Windows.Forms.Label entPassLabel;
        private System.Windows.Forms.Label outPassLabel;
        private System.Windows.Forms.Button recallBtn;
        private System.Windows.Forms.Button generateBtn;
        private System.Windows.Forms.TextBox acctNameTxtbox;
        private System.Windows.Forms.TextBox usrNameTxtbox;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Label mastPassLabel;
        private System.Windows.Forms.TextBox masterPassTxtbox;
        private System.Windows.Forms.Button setBtn;
    }
}

