﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch._4_Hurricane_Categorizer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            answerLabel.Visible = true;
            const int CAT5 = 157, CAT4 = 130, CAT3 = 111, CAT2 = 96, CAT1 = 74;
            int enteredWindSpeed;
            enteredWindSpeed = Convert.ToInt32(windSpeedTextbox.Text);
            if (enteredWindSpeed < CAT1)
                answerLabel.Text = ("There is no hurricane.");
            else if (enteredWindSpeed >= CAT1 && enteredWindSpeed < CAT2)
                answerLabel.Text = ("This is a category 1 hurricane.");
            else if (enteredWindSpeed >= CAT2 && enteredWindSpeed < CAT3)
                answerLabel.Text = ("This is a category 2 hurricane.");
            else if (enteredWindSpeed >= CAT3 && enteredWindSpeed < CAT4)
                answerLabel.Text = ("This is a category 3 hurricane.");
            else if (enteredWindSpeed >= CAT4 && enteredWindSpeed < CAT5)
                answerLabel.Text = ("This is a category 4 hurricane.");
            else answerLabel.Text = ("This is a category 5 hurricane.");
        }
    }
}
