﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pig_Latin_Converter
{
    public partial class pigLatinConverter : Form
    {
        public pigLatinConverter()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            convertedWordLabel.Visible = true;
            string wordEntered, wordTranslated;
            wordEntered = userInputWordTextBox.Text;
            wordTranslated = wordEntered.Substring(1, wordEntered.Length - 1) + wordEntered.Substring(0, 1) + "ay";
            convertedWordLabel.Text = wordTranslated;
        }
    }
}
