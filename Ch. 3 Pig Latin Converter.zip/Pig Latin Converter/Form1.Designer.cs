﻿namespace Pig_Latin_Converter
{
    partial class pigLatinConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.converterNameLabel = new System.Windows.Forms.Label();
            this.enterWordHereLabel = new System.Windows.Forms.Label();
            this.userInputWordTextBox = new System.Windows.Forms.TextBox();
            this.convertButton = new System.Windows.Forms.Button();
            this.convertedWordLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // converterNameLabel
            // 
            this.converterNameLabel.AutoSize = true;
            this.converterNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.converterNameLabel.Location = new System.Drawing.Point(232, 9);
            this.converterNameLabel.Name = "converterNameLabel";
            this.converterNameLabel.Size = new System.Drawing.Size(309, 37);
            this.converterNameLabel.TabIndex = 0;
            this.converterNameLabel.Text = "Pig Latin Converter";
            // 
            // enterWordHereLabel
            // 
            this.enterWordHereLabel.AutoSize = true;
            this.enterWordHereLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterWordHereLabel.Location = new System.Drawing.Point(127, 89);
            this.enterWordHereLabel.Name = "enterWordHereLabel";
            this.enterWordHereLabel.Size = new System.Drawing.Size(240, 20);
            this.enterWordHereLabel.TabIndex = 1;
            this.enterWordHereLabel.Text = "Enter word to be converted here:";
            // 
            // userInputWordTextBox
            // 
            this.userInputWordTextBox.Location = new System.Drawing.Point(373, 89);
            this.userInputWordTextBox.Name = "userInputWordTextBox";
            this.userInputWordTextBox.Size = new System.Drawing.Size(339, 20);
            this.userInputWordTextBox.TabIndex = 2;
            // 
            // convertButton
            // 
            this.convertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertButton.Location = new System.Drawing.Point(239, 290);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(278, 37);
            this.convertButton.TabIndex = 3;
            this.convertButton.Text = "Click here to convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // convertedWordLabel
            // 
            this.convertedWordLabel.AutoSize = true;
            this.convertedWordLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.convertedWordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertedWordLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.convertedWordLabel.Location = new System.Drawing.Point(344, 182);
            this.convertedWordLabel.Name = "convertedWordLabel";
            this.convertedWordLabel.Size = new System.Drawing.Size(0, 24);
            this.convertedWordLabel.TabIndex = 4;
            this.convertedWordLabel.Visible = false;
            // 
            // pigLatinConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.convertedWordLabel);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.userInputWordTextBox);
            this.Controls.Add(this.enterWordHereLabel);
            this.Controls.Add(this.converterNameLabel);
            this.Name = "pigLatinConverter";
            this.Text = "Pig Latin Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label converterNameLabel;
        private System.Windows.Forms.Label enterWordHereLabel;
        private System.Windows.Forms.TextBox userInputWordTextBox;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Label convertedWordLabel;
    }
}

